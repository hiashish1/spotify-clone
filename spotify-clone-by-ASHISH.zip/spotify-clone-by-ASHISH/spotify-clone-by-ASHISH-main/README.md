Coding Raja internship task 2

This spotify clone is for educational purpose


Best viewed in (desktop only) [Here is Preview of project] - https://spotifyclonebysanket.netlify.app/

Copyright Disclaimer:

This project is a learning exercise undertaken by ASHISH for educational purposes in the field of web development. The project, a Spotify clone, is intended to demonstrate skills acquired during the learning process involving HTML, CSS, and JavaScript.

Fair Use:

All materials used in this project, including but not limited to design elements, layout, and functionalities, are created solely for educational and non-commercial purposes. The project seeks to replicate certain aspects of the Spotify platform for educational and portfolio demonstration purposes only.

Originality:

While efforts have been made to mimic the appearance and functionality of the Spotify platform, no copyrighted materials owned by Spotify or any other entity have been used in this project. All design elements, code snippets, and content are original creations of ASHISH or have been sourced from freely available resources with proper attribution.

Attribution:

Any resources, libraries, or frameworks utilized in the development of this project that are not original creations of [Your Name] have been properly attributed. All third-party resources are used in accordance with their respective licenses and terms of use.
